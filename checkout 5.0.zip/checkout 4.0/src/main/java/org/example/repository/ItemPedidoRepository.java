package org.example.repository;

import org.example.models.ItemPedido;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class ItemPedidoRepository {
    private EntityManagerFactory entityManagerFactory;

    public ItemPedidoRepository() {
        this.entityManagerFactory = Persistence.createEntityManagerFactory("NomeDaUnidadeDePersistencia");
    }

    public void adicionarItemPedido(ItemPedido itemPedido) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        try {
            entityManager.persist(itemPedido);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    public ItemPedido buscarItemPedidoPorId(int idItemPedido) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        ItemPedido itemPedido = null;

        try {
            itemPedido = entityManager.find(ItemPedido.class, idItemPedido);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            entityManager.close();
        }

        return itemPedido;
    }

    public List<ItemPedido> listarItensPedido() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        List<ItemPedido> itensPedido = null;

        try {
            itensPedido = entityManager.createQuery("SELECT ip FROM ItemPedido ip", ItemPedido.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            entityManager.close();
        }

        return itensPedido;
    }

    public void atualizarItemPedido(ItemPedido itemPedido) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        try {
            entityManager.merge(itemPedido);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    public void deletarItemPedido(int idItemPedido) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();

        try {
            ItemPedido itemPedido = entityManager.find(ItemPedido.class, idItemPedido);
            if (itemPedido != null) {
                entityManager.remove(itemPedido);
            }
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }
}
