package org.example.controller;

import org.example.models.ItemPedido;
import org.example.models.Pedido;
import org.example.models.Produto;
import org.example.repository.ItemPedidoRepository;
import org.example.repository.PedidoRepository;
import org.example.repository.ProdutoRepository;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CarrinhoController {
    private List<ItemPedido> carrinho;
    private double totalCompra;
    private ProdutoRepository produtoRepository;
    private ItemPedidoRepository itemPedidoRepository;
    private PedidoRepository pedidoRepository;

    public CarrinhoController() {
        this.carrinho = new ArrayList<>();
        this.totalCompra = 0.0;
        this.produtoRepository = new ProdutoRepository();
        this.itemPedidoRepository = new ItemPedidoRepository();
        this.pedidoRepository = new PedidoRepository();
    }

    public void adicionarItem(int idProduto, int quantidade) {
        Produto produto = produtoRepository.buscarProdutoPorId(idProduto);

        if (produto != null) {
            ItemPedido item = new ItemPedido();
            item.setProduto(produto);
            item.setQuantidade(quantidade);
            item.setPreco(produto.getPreco() * quantidade);

            carrinho.add(item);

            totalCompra += item.getPreco();


         

        }
    }



    public double getTotalCompra() {
        return totalCompra;
    }

    public String gerarRecibo() {
        StringBuilder recibo = new StringBuilder();
        recibo.append("Recibo da Compra:\n");
        recibo.append("--------------------------\n");

        for (ItemPedido item : carrinho) {
            recibo.append(item.getProduto().getNomeProduto())
                    .append(" - Quantidade: ").append(item.getQuantidade())
                    .append(" - Preço: ").append(item.getPreco()).append("\n");
        }

        DecimalFormat df = new DecimalFormat("#.##");
        recibo.append("--------------------------\n");
        recibo.append("Total da Compra: ").append(df.format(totalCompra));

        return recibo.toString();
    }

    public void removerItem(int index) {
        if (index >= 0 && index < carrinho.size()) {
            ItemPedido itemRemovido = carrinho.remove(index);
            totalCompra -= itemRemovido.getPreco();
        }
    }

    public List<ItemPedido> getCarrinho() {
        return carrinho;
    }

    public boolean finalizarCompra(String metodoPagamento) {
        boolean pagamentoBemSucedido = simularPagamento();

        if (pagamentoBemSucedido) {
            for (ItemPedido item : carrinho) {
                itemPedidoRepository.adicionarItemPedido(item);
            }

            Pedido pedido = new Pedido();
            pedido.setTotalCompra(totalCompra);
            pedidoRepository.adicionarPedido(pedido);

            String recibo = gerarRecibo();
            System.out.println(recibo);

            carrinho.clear();
            totalCompra = 0.0;
            return true;
        } else {
            System.out.println("Erro no processo de pagamento, tente novamente");
        }return false;
    }

    private boolean simularPagamento() {
        Random random = new Random();
        return random.nextDouble() < 0.9; // 90% de chance de sucesso
    }
}

