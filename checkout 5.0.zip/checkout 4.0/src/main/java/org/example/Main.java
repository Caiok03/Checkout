package org.example;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.example.models.Produto;
import org.example.repository.ProdutoRepository;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("NomeDaUnidadeDePersistencia");
        
        ProdutoRepository produtoRepository = new ProdutoRepository();

        // Criando um novo produto
        Produto novoProduto = new Produto();
        novoProduto.setNomeProduto("Chocolate");
        novoProduto.setUnidade(15);
        novoProduto.setPreco(5.2);
        
        Produto novoProduto2 = new Produto();
        novoProduto.setNomeProduto("bala");
        novoProduto.setUnidade(1);
        novoProduto.setPreco(1.5);

        // Salvando o novo produto no banco de dados
        produtoRepository.salvarProduto(novoProduto);

        System.out.println("Novo produto inserido com sucesso!");
    }
    }